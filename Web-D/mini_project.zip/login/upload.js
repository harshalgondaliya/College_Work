const fileInput = document.getElementById('file-upload');
const formData = new FormData();

fileInput.addEventListener('change', function(event) {
    const files = event.target.files;
    for (let i = 0; i < files.length; i++) {
        formData.append('documents', files[i]);
    }
});

document.querySelector('form').addEventListener('submit', function(event) {
    event.preventDefault();
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'upload.php', true);
    xhr.onload = function() {
        if (xhr.status === 200) {
            console.log('Files uploaded successfully!');
        } else {
            console.error('Error uploading files:', xhr.statusText);
        }
    };
    xhr.send(formData);
});