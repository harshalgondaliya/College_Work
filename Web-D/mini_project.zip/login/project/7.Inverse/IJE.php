<!DOCTYPE html>
<html>

<head>
    <title>Inverse Matrix Calculation using Gauss-Jordan Elimination</title>
    <link rel="stylesheet" href="IJE.css">
</head>

<body>
    <div class="container ">
        <h2>Inverse Matrix Calculation using Gauss-Jordan Elimination</h2>
        <p>Enter the number of rows and columns for matrix A:</p>
        <label for="numRows">Number of Rows:</label>
        <input type="number" id="numRows">
        <br>
        <label for="numCols">Number of Columns:</label>
        <input type="number" id="numCols">
        <br>
        <div id="matrixInputs"></div>
        <br>
        <button onclick="findInverse()">Calculate Inverse</button>
        <div id="inverseMatrix"></div>

        <script src="IJE.js ">
        </script>
    </div>
</body>

</html>