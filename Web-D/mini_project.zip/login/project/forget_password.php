<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'student_portal');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $conn->real_escape_string($_POST['email']);
    $security_answer = $conn->real_escape_string($_POST['security_answer']);

    // Check if email exists and security answer matches
    $sql = "SELECT * FROM users WHERE email='$email' AND security_answer='$security_answer'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Generate 6-digit code for password reset
        $reset_code = rand(100000, 999999);
        $expiry_time = date("Y-m-d H:i:s", strtotime('+15 minutes'));

        // Update user with reset code and expiry
        $sql = "UPDATE users SET reset_code='$reset_code', reset_code_expiry='$expiry_time' WHERE email='$email'";
        $conn->query($sql);

        // Send the reset code via email
        $subject = "Password Reset Code";
        $message = "Your password reset code is: $reset_code. It will expire in 15 minutes.";
        mail($email, $subject, $message);

        header("Location: reset_password.php?email=$email");
        exit();
    } else {
        $error = "No account found or incorrect security answer.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Forgot Password</h1><br>
        <form action="" method="post">
            <label for="email">Enter your email:</label>
            <input type="email" id="email" name="email" required><br>

            <label for="security_answer">What is the thing you like in the whole world?</label>
            <input type="text" id="security_answer" name="security_answer" required><br>

            <button type="submit">Verify</button>
        </form>
        <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?><br>
        <p><a href="login.php">Back to Login</a></p>
    </div>
</body>
</html>
