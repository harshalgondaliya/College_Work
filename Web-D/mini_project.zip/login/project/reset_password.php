<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'student_portal');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_GET['email'];
    $new_password = password_hash($_POST['new_password'], PASSWORD_BCRYPT);

    // Update the password
    $sql = "UPDATE users SET password='$new_password' WHERE email='$email'";
    if ($conn->query($sql) === TRUE) {
        echo "Password updated successfully.";
        header("Location: login.php");
        exit();
    } else {
        echo "Error updating password: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Reset Your Password</h1>
        <form action="" method="post">
            <label for="new_password">New Password:</label>
            <input type="password" id="new_password" name="new_password" required><br>
            <button type="submit">Reset Password</button>
        </form>
    </div>
</body>
</html>
