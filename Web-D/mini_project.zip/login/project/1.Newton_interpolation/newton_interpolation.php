<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Newton Interpolation</title>
    <link rel="stylesheet" href="../style.css">
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/boxicons/2.0.7/css/boxicons.min.css">
</head>

<body>
    <div class="container">
        <h1>Newton Interpolation</h1>
        <form method="post">
            <label for="x_values">Enter x values:</label>
            <input type="text" name="x_values" id="x_values" placeholder="Comma-separated values"><br>

            <label for="y_values">Enter f(x) values:</label>
            <input type="text" name="y_values" id="y_values" placeholder="Comma-separated values"><br>

            <label for="interpolate">Enter the x value to interpolate:</label>
            <input type="text" name="interpolate" id="interpolate" placeholder="Initial value"><br>

            <button type="submit" name="calculate">Calculate</button>
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["calculate"])) {
            $x_values = explode(",", $_POST["x_values"]);
            $y_values = explode(",", $_POST["y_values"]);
            $interpolate_x = floatval($_POST["interpolate"]);

            if (count($x_values) == count($y_values)) {
                $n = count($x_values);
                for ($i = 0; $i < $n; $i++) {
                    $x_values[$i] = floatval($x_values[$i]);
                    $y_values[$i] = floatval($y_values[$i]);
                }

                function newton_interpolation($x, $y, $xi) {
                    $n = count($x);
                    $diff_table = [];
                    for ($i = 0; $i < $n; $i++) {
                        $diff_table[$i][0] = $y[$i];
                    }
                    for ($j = 1; $j < $n; $j++) {
                        for ($i = 0; $i < $n - $j; $i++) {
                            $diff_table[$i][$j] = ($diff_table[$i + 1][$j - 1] - $diff_table[$i][$j - 1]) / ($x[$i + $j] - $x[$i]);
                        }
                    }
                    $result = $diff_table[0][0];
                    $product = 1;
                    for ($i = 1; $i < $n; $i++) {
                        $product *= ($xi - $x[$i - 1]);
                        $result += $product * $diff_table[0][$i];
                    }
                    return $result;
                }

                $result = newton_interpolation($x_values, $y_values, $interpolate_x);
                echo "<p>Interpolated value at x = $interpolate_x is: $result</p>";
            } else {
                echo "<p style='color:red;'>Error: The number of x values and f(x) values must be the same.</p>";
            }
        }
        ?>
    </div>

    <footer class="footer">
        <div style="display: flex; justify-content: space-between;">
            <div>
                <br>
                <a class="footer__copy" style="margin-left: 20px;">Harshal Gondaliya<sup>&reg;</sup></a>
            </div>
            <div style="text-align: right;">
                <br>
                <a class="footer__info" style="margin-right: 20px;">+91 8511257368</a><br><br><br>
            </div>
        </div>
        <div style="display: flex; justify-content: space-between;">
            <div>
                <a class="footer__copy" style="margin-left: 20px;">Since 2022. All rights reserved</a>
            </div>
            <div class="footer__social">
                <div>
                    <a href="https://www.linkedin.com/in/harshalgondaliya/" class="home__social-icon" style="color: #0092E0;">
                        <i class='bx bxl-linkedin'></i>
                    </a>
                    <a href="https://www.instagram.com/harshal_gondaliya/" class="home__social-icon" style="color: #E4405F;">
                        <i class='bx bxl-instagram'></i>
                    </a>
                    <a href="https://github.com/harshalgondaliya" class="home__social-icon" style="color: #000000;">
                        <i class='bx bxl-github'></i>
                    </a><br>
                </div>
            </div>
            <div style="text-align: right;">
                <a class="footer__info" style="margin-right: 20px;">harshalgondaliya07@gmail.com</a><br>
            </div>
        </div>
    </footer>

    <!--===== SCROLL REVEAL =====-->
    <script src="https://unpkg.com/scrollreveal"></script>

</body>

</html>
