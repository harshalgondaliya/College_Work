<!DOCTYPE html>
<html>

<head>
    <title>Matrix Rank Calculator</title>
    <link rel="stylesheet" type="text/css" href="r.css">
</head>

<body>
    <div class="container">
        <h2>Enter values for a matrix:</h2>
        <div>
            <label for="rows">Number of Rows: </label>
            <input type="number" id="rows" min="1" value="3">
        </div>
        <br>
        <div>
            <label for="cols">Number of Columns:</label>
            <input type="number" id="cols" min="1" value="3">
        </div>
        <br>
        <div class="middle">
            <button onclick="createMatrixInput()">Create Matrix Input</button>
            <br><br>
            <table id="matrixInput"></table>
            <button onclick="calculateRank()">Calculate Rank</button>
            <div id="finalMatrix"></div>
            <p id="rank"></p>
        </div>
        <script src=" https://unpkg.com/scrollreveal "></script>

        <script src="r.js">
        </script>
    </div>
</body>

</html>