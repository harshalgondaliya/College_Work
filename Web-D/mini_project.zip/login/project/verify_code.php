<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'student_portal');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_GET['email'] ?? '';  // Get email from query parameter if available

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $code = $conn->real_escape_string($_POST['code']);
    
    // SQL query to check if the code and email match and the reset code is still valid
    $sql = "SELECT * FROM users WHERE email='$email' AND reset_code='$code' AND reset_code_expiry > NOW()";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Code is correct, redirect to reset password page with email as parameter
        header("Location: reset_password.php?email=$email");
        exit();
    } else {
        $error = "Invalid or expired code.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Verify Code</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Verify Code</h1>
        <form action="" method="post">
            <label for="code">Enter the 6-digit code:</label>
            <input type="text" id="code" name="code" required maxlength="6"><br>
            <button type="submit">Verify Code</button>
        </form>
        <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
        <p><a href="forget_password.php">Back to Forgot Password</a></p>
    </div>
</body>
</html>
