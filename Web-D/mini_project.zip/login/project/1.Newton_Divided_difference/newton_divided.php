<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Newton Divided Difference</title>
    <link rel="stylesheet" href="newton_divided.css">
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/boxicons/2.0.7/css/boxicons.min.css">
    <script>
        function divided() {
            // Replace 'photo.jpg' with the path to your photo
            window.open('divided.jpg', '_blank');
        }
    </script>

</head>

<body>
    <div class="container">
        <h1>Newton Divided Difference Interpolation Polynomial</h1>
        <div id="input">
            <label for="xValues">Enter x values :</label>
            <input type="text" placeholder="(Comma separeted)" id="xValues"><br>
            <label for="yValues">Enter f(x) values :</label>
            <input type="text" placeholder="(Comma separeted)" id="yValues"><br>
            <label for="x">Enter finding x value :</label>
            <input type="number" placeholder="(Initial values)" id="x"><br>
            <button onclick="calculateInterpolation()">Calculate Divided Difference</button>
        </div>
        <div id="output">
            <h2>Result:</h2>
            <p id="result"></p>
        </div>
    </div>
    <footer class="footer ">
        <div style="display: flex; justify-content: space-between; ">
            <div>
                <br>
                <a class="footer__copy " style="margin-left: 20px; " ">Harshal Gondaliya<sup>&reg;</sup></a>
            </div>
            <div style=" text-align: right; ">
                <br>
                <a class="footer__info " style="margin-right: 20px; ">+91 8511257368</a><br><br><br>
            </div>
        </div>
        <div style="display: flex; justify-content: space-between; ">
            <div>
                <a class="footer__copy " style="margin-left: 20px; " ">Since 2022. All rights reserved</a>
            </div>
            <div class="footer__social ">
                <div>
                    <a href="https://www.linkedin.com/in/harshalgondaliya/ " class="home__social-icon " style="color: #0092E0; "><i class='bx bxl-linkedin'></i></a>
                    <a href="https://www.instagram.com/harshal_gondaliya/ " class="home__social-icon " style="color: #E4405F; "><i class='bx bxl-instagram'></i></a>
                    <a href="https://github.com/harshalgondaliya " class="home__social-icon " style="color: #000000; "><i class='bx bxl-github' ></i></a><br>
                </div>
            </div>
            <div style=" text-align: right; ">
                <a class="footer__info " style="margin-right: 20px; ">harshalgondaliya07@gmail.com</a><br>
            </div>
        </div>
    </footer>

    <!--===== SCROLL REVEAL =====-->
    <script src=" https://unpkg.com/scrollreveal "></script>
    <script src="newton_divided.js">
    </script>

</body>

</html>